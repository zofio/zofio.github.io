1.Put payload.bin to "payload_input" folder
2.Run payload_dumper.exe
3.Successfully extracted img files are in "payload_output" folder

************Don't delete "payload_output" folder************

Source code https://gist.github.com/ius/42bd02a5df2226633a342ab7a9c60f15
Thanks ius, Tadi777